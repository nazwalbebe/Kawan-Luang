import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Routes
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      
      const chat = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction: `Kamu adalah 'Jiwa', seorang pendamping kesehatan mental yang hangat, empati, dan mendukung khusus untuk mahasiswa Indonesia. 
          Gunakan bahasa Indonesia yang santai tapi sopan (seperti kakak tingkat atau teman baik).
          Fokus pada mendengarkan, memberikan validasi atas perasaan mereka, dan memberikan saran praktis untuk mengatasi stres kuliah, organisasi, atau masalah sehari-hari.
          Jangan memberikan diagnosa medis. Jika pengguna menunjukkan tanda-tanda bahaya (ingin menyakiti diri sendiri), arahkan dengan sangat lembut ke profesional kesehatan.
          Buat percakapan terasa personal dan tidak kaku.`,
        },
        // We can pass history here if needed, but SDK expects Specific history format.
        // For simplicity in this demo, we'll just send the current message or handle simple history.
      });

      // Simple implementation of sending the message.
      const result = await chat.sendMessage({ message });
      res.json({ text: result.text });
    } catch (error: any) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Terjadi kesalahan saat berbicara dengan Jiwa." });
    }
  });

  // Daily Quote endpoint (optional, could be powered by AI or static)
  app.get("/api/quote", async (req, res) => {
    try {
      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: "Berikan satu quote motivasi singkat dalam bahasa Indonesia untuk mahasiswa yang sedang stres. Berikan hanya teks quotenya saja tanpa kutipan.",
      });
      res.json({ quote: result.text });
    } catch (error) {
      res.json({ quote: "Istirahatlah sejenak, kamu sudah berusaha dengan hebat hari ini." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
