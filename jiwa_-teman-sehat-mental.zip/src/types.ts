export type MoodType = 'happy' | 'neutral' | 'sad' | 'stressed' | 'tired' | 'peaceful';

export interface MoodEntry {
  id: string;
  date: string;
  mood: MoodType;
  note?: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  title: string;
  content: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface SelfCareTask {
  id: string;
  title: string;
  completed: boolean;
}
