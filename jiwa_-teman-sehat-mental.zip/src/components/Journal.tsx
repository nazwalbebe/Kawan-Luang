import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, Plus, X, Search, Calendar, ChevronRight, Save } from 'lucide-react';
import { JournalEntry } from '../types';

export default function Journal() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('journal_entries');
    if (saved) setEntries(JSON.parse(saved));
  }, []);

  const handleSave = () => {
    if (!title.trim() || !content.trim()) return;

    const newEntry: JournalEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      title,
      content
    };

    const updated = [newEntry, ...entries];
    setEntries(updated);
    localStorage.setItem('journal_entries', JSON.stringify(updated));
    setTitle('');
    setContent('');
    setIsAdding(false);
  };

  return (
    <div className="space-y-8 py-4">
      <section className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#4A4A4A]">Jurnal Harian</h2>
          <p className="text-natural-tertiary mt-1">Abadikan pikiran dan momenmu.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-natural-brand text-white p-4 rounded-3xl shadow-lg shadow-natural-brand/10 hover:scale-105 active:scale-95 transition-all"
        >
          <Plus className="w-6 h-6" />
        </button>
      </section>

      {/* Entry List */}
      <section className="space-y-6">
        {entries.length === 0 ? (
          <div className="bg-[#EAE7DF] p-12 rounded-[40px] border border-dashed border-natural-border text-center">
            <BookOpen className="w-16 h-16 text-natural-tertiary opacity-20 mx-auto mb-4" />
            <p className="text-natural-tertiary font-bold uppercase tracking-widest text-[10px]">Tulis cerita pertamamu hari ini</p>
            <button 
              onClick={() => setIsAdding(true)}
              className="text-natural-brand text-sm font-bold mt-4 px-6 py-2 bg-white rounded-2xl shadow-sm"
            >
              Mulai Menulis
            </button>
          </div>
        ) : (
          <div className="grid gap-6">
            {entries.map((entry) => (
              <button 
                key={entry.id}
                onClick={() => setSelectedEntry(entry)}
                className="bg-white p-7 rounded-[40px] border border-natural-border text-left hover:border-natural-accent/50 transition-all shadow-sm active:scale-[0.98] group"
              >
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-bold text-natural-brand bg-natural-light/40 px-4 py-1.5 rounded-full uppercase tracking-widest">
                    {new Date(entry.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                </div>
                <h3 className="font-bold text-xl text-[#4A4A4A] mb-3 group-hover:text-natural-brand transition-colors">{entry.title}</h3>
                <p className="text-sm text-natural-tertiary line-clamp-3 leading-relaxed">{entry.content}</p>
                <div className="mt-6 pt-6 border-t border-natural-border flex items-center justify-between text-natural-brand text-[10px] font-bold uppercase tracking-widest">
                  <span>Selesai Dibaca</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Add/View Overlays */}
      <AnimatePresence>
        {(isAdding || selectedEntry) && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-natural-brand/40 backdrop-blur-md z-50 p-6 flex items-end sm:items-center justify-center"
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="bg-natural-bg w-full max-w-xl h-[90vh] rounded-[48px] overflow-hidden flex flex-col p-8 relative shadow-2xl border border-white/50"
            >
              <button 
                onClick={() => { setIsAdding(false); setSelectedEntry(null); }}
                className="absolute top-8 right-8 p-3 bg-white/80 rounded-2xl text-natural-tertiary hover:bg-white transition-colors shadow-sm"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="mt-10 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                {isAdding ? (
                  <div className="space-y-8">
                    <div>
                      <p className="text-[10px] font-bold text-natural-brand uppercase tracking-widest mb-4">Draft Jurnal Baru</p>
                      <input 
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Apa judul harimu?"
                        className="w-full text-3xl font-bold placeholder:text-natural-tertiary/20 border-none focus:ring-0 p-0 text-[#2D3748] bg-transparent"
                        autoFocus
                      />
                    </div>
                    <div className="w-16 h-1 bg-natural-accent rounded-full" />
                    <div>
                      <textarea 
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        placeholder="Tuliskan apapun, biarkan kata-kata mengalir..."
                        className="w-full h-[400px] text-lg text-natural-tertiary/80 border-none focus:ring-0 p-0 resize-none leading-relaxed bg-transparent"
                      />
                    </div>
                    <button 
                      onClick={handleSave}
                      className="w-full bg-natural-brand text-white py-5 rounded-[32px] font-bold shadow-xl shadow-natural-brand/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3"
                    >
                      <Save className="w-6 h-6" /> Simpan Jurnal
                    </button>
                  </div>
                ) : selectedEntry && (
                  <div className="space-y-6">
                     <p className="text-[10px] font-bold text-natural-brand uppercase tracking-widest bg-natural-light/40 inline-block px-4 py-1.5 rounded-full">
                      {new Date(selectedEntry.date).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                    <h2 className="text-4xl font-bold text-[#4A4A4A] leading-tight">{selectedEntry.title}</h2>
                    <div className="w-20 h-1.5 bg-natural-accent/30 rounded-full" />
                    <p className="text-xl text-natural-tertiary/90 leading-relaxed whitespace-pre-wrap font-medium">{selectedEntry.content}</p>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
