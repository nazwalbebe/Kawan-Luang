import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Coffee, Wind, Sun, CheckCircle2, Circle, Sparkles, BookOpen, Brain, Heart } from 'lucide-react';
import { SelfCareTask } from '../types';

const INITIAL_TASKS: SelfCareTask[] = [
  { id: '1', title: 'Minum segelas air putih', completed: false },
  { id: '2', title: 'Istirahat 5 menit dari layar', completed: false },
  { id: '3', title: 'Lakukan teknik napas 4-7-8', completed: false },
  { id: '4', title: 'Apresiasi diri sendiri hari ini', completed: false },
  { id: '5', title: 'Makan tepat waktu', completed: false },
];

export default function SelfCare() {
  const [tasks, setTasks] = useState<SelfCareTask[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('self_care_tasks');
    if (saved) {
      setTasks(JSON.parse(saved));
    } else {
      setTasks(INITIAL_TASKS);
    }
  }, []);

  const toggleTask = (id: string) => {
    const updated = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    setTasks(updated);
    localStorage.setItem('self_care_tasks', JSON.stringify(updated));
  };

  const resetTasks = () => {
    setTasks(INITIAL_TASKS);
    localStorage.setItem('self_care_tasks', JSON.stringify(INITIAL_TASKS));
  };

  return (
    <div className="space-y-10 py-4">
      <section>
        <h2 className="text-2xl font-bold text-[#4A4A4A]">Self-Care & Tips</h2>
        <p className="text-natural-tertiary mt-1">Investasi kecil untuk kebaikan dirimu.</p>
      </section>

      {/* Daily Routine Cards */}
      <section className="bg-white p-8 rounded-[40px] border border-natural-border shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-sm font-bold flex items-center gap-2 uppercase tracking-widest opacity-40">
            Pengingat Diri
          </h3>
          <button 
            onClick={resetTasks}
            className="text-[10px] font-bold text-natural-brand uppercase tracking-widest hover:underline"
          >
            Reset
          </button>
        </div>
        
        <div className="space-y-4">
          {tasks.map((task) => (
            <button 
              key={task.id}
              onClick={() => toggleTask(task.id)}
              className={`w-full flex items-center gap-4 p-5 rounded-3xl border transition-all ${
                task.completed 
                  ? 'bg-natural-muted border-transparent text-natural-tertiary opacity-40 line-through' 
                  : 'bg-natural-bg border-natural-border text-natural-tertiary hover:border-natural-accent'
              }`}
            >
              <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${task.completed ? 'bg-natural-accent text-white' : 'bg-white border-2 border-natural-border'}`}>
                {task.completed && <CheckCircle2 className="w-5 h-5" />}
              </div>
              <span className="text-sm font-bold tracking-tight">{task.title}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Wellness Tips */}
      <section className="space-y-6">
        <h3 className="font-bold text-lg flex items-center gap-2">
           <span className="w-2 h-6 bg-natural-accent rounded-full"></span>
          Edukasi & Tips
        </h3>
        <div className="grid gap-6">
          <TipCard 
            icon={<Wind className="text-blue-500" />}
            title="Teknik Napas 4-7-8"
            description="Tarik napas 4 detik, tahan 7 detik, buang napas 8 detik. Ulangi 4 kali untuk relaksasi instan."
            bg="bg-[#E8F3FF]"
          />
          <TipCard 
            icon={<Sun className="text-orange-500" />}
            title="Sinar Matahari Pagi"
            description="Luangkan 10-15 menit di bawah matahari pagi untuk memperbaiki mood dan durasi tidurmu."
            bg="bg-[#FFF6E3]"
          />
          <TipCard 
            icon={<Coffee className="text-[#8B4513]" />}
            title="Mindful Moment"
            description="Saat minum, fokus pada sensasi hangat dan aroma. Berikan otakmu jeda dari notifikasi."
            bg="bg-natural-muted"
          />
        </div>
      </section>
    </div>
  );
}

function TipCard({ icon, title, description, bg }: { icon: React.ReactNode, title: string, description: string, bg: string }) {
  return (
    <div className={`${bg} p-6 rounded-[40px] flex gap-5 border border-white shadow-sm`}>
      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shrink-0 shadow-sm">
        {icon}
      </div>
      <div>
        <h4 className="font-bold text-sm text-natural-brand mb-1">{title}</h4>
        <p className="text-xs text-natural-tertiary/80 leading-relaxed font-medium">{description}</p>
      </div>
    </div>
  );
}
