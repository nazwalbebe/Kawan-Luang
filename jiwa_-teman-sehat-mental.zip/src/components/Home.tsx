import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles, MessageCircle, BookOpen, Brain, Heart, ArrowRight } from 'lucide-react';

export default function Home({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const [quote, setQuote] = useState<string>("Sedang mengambil motivasi untukmu...");
  const [userName] = useState("Fakhri"); // Updated default to match design reference

  useEffect(() => {
    fetch('/api/quote')
      .then(res => res.json())
      .then(data => setQuote(data.quote))
      .catch(() => setQuote("Hari ini adalah kesempatan baru untuk menjadi lebih baik."));
  }, []);

  return (
    <div className="space-y-10 py-4">
      {/* Welcome Section */}
      <section>
        <h2 className="text-3xl font-bold text-[#4A4A4A]">Halo, {userName} 👋</h2>
        <p className="text-natural-tertiary mt-2">Bagaimana perasaanmu di kampus hari ini?</p>
      </section>

      {/* Daily Quote Card */}
      <motion.section 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white/60 backdrop-blur-md border border-white p-8 rounded-[40px] shadow-sm relative overflow-hidden"
      >
        <Sparkles className="absolute -right-4 -top-4 w-20 h-20 text-natural-accent opacity-20" />
        <div className="relative z-10">
          <p className="text-lg font-medium italic text-natural-tertiary leading-relaxed">
            "{quote}"
          </p>
          <p className="text-xs font-bold mt-4 text-natural-brand uppercase tracking-widest text-right">— Motivasi Hari Ini</p>
        </div>
      </motion.section>

      {/* Quick Actions Grid - Refined with Design Colors */}
      <section className="grid grid-cols-2 gap-6">
        <QuickActionCard 
          icon={<MessageCircle className="text-natural-brand" />}
          label="Teman Cerita"
          color="bg-natural-light/50"
          onClick={() => onNavigate('chat')}
        />
        <QuickActionCard 
          icon={<Brain className="text-[#889E73]" />}
          label="Mood Tracker"
          color="bg-[#F2FFED]"
          onClick={() => onNavigate('mood')}
        />
        <QuickActionCard 
          icon={<BookOpen className="text-[#969488]" />}
          label="Jurnal Harian"
          color="bg-natural-muted"
          onClick={() => onNavigate('journal')}
        />
        <QuickActionCard 
          icon={<Heart className="text-[#D9A5B3]" />}
          label="Self-Care"
          color="bg-[#FEECEC]"
          onClick={() => onNavigate('self-care')}
        />
      </section>

      {/* Streak / Placeholder Section from Design */}
      <section className="bg-natural-muted p-6 rounded-[32px] border border-natural-border shadow-sm">
        <p className="text-xs uppercase tracking-widest font-bold text-natural-tertiary opacity-60 mb-3">Self-Care Streak</p>
        <div className="flex gap-2 mb-4">
          <div className="w-3 h-3 rounded-full bg-natural-accent"></div>
          <div className="w-3 h-3 rounded-full bg-natural-accent"></div>
          <div className="w-3 h-3 rounded-full bg-natural-accent"></div>
          <div className="w-3 h-3 rounded-full bg-natural-border"></div>
          <div className="w-3 h-3 rounded-full bg-natural-border"></div>
        </div>
        <p className="text-sm font-semibold text-natural-tertiary">3 Hari Berturut-turut! Lanjutkan perjuanganmu.</p>
      </section>
    </div>
  );
}

function QuickActionCard({ icon, label, color, onClick }: { icon: React.ReactNode, label: string, color: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`${color} p-6 rounded-[32px] flex flex-col items-center text-center gap-4 transition-all hover:scale-[1.02] active:scale-95 border border-natural-border shadow-sm`}
    >
      <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-xs">
        {icon}
      </div>
      <span className="text-sm font-bold text-natural-tertiary">{label}</span>
    </button>
  );
}
