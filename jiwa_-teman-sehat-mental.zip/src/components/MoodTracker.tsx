import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Smile, 
  Meh, 
  Frown, 
  Zap, 
  Moon, 
  Sun, 
  Activity,
  ChevronRight,
  TrendingUp
} from 'lucide-react';
import { MoodType, MoodEntry } from '../types';

const MOODS: { type: MoodType; label: string; icon: any; color: string; bg: string }[] = [
  { type: 'happy', label: 'Senang', icon: Smile, color: 'text-orange-500', bg: 'bg-[#FEECEC]' },
  { type: 'tired', label: 'Lelah', icon: Sun, color: 'text-blue-500', bg: 'bg-[#E8F3FF]' },
  { type: 'peaceful', label: 'Tenang', icon: Moon, color: 'text-natural-brand', bg: 'bg-[#F2FFED]' },
  { type: 'stressed', label: 'Stres', icon: Zap, color: 'text-yellow-600', bg: 'bg-[#FFF6E3]' },
  { type: 'sad', label: 'Sedih', icon: Frown, color: 'text-indigo-500', bg: 'bg-[#F2EFFF]' },
  { type: 'neutral', label: 'Biasa Saja', icon: Meh, color: 'text-natural-tertiary', bg: 'bg-natural-muted' },
];

export default function MoodTracker() {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [note, setNote] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('mood_entries');
    if (saved) setEntries(JSON.parse(saved));
  }, []);

  const handleSave = () => {
    if (!selectedMood) return;

    const newEntry: MoodEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      mood: selectedMood,
      note: note.trim() || undefined
    };

    const updated = [newEntry, ...entries].slice(0, 50); // Keep last 50
    setEntries(updated);
    localStorage.setItem('mood_entries', JSON.stringify(updated));
    setSelectedMood(null);
    setNote('');
  };

  const getMoodConfig = (type: MoodType) => MOODS.find(m => m.type === type)!;

  return (
    <div className="space-y-10 py-4">
      <section>
        <h2 className="text-2xl font-bold text-[#4A4A4A]">Mood Tracker</h2>
        <p className="text-natural-tertiary mt-1">Simpan perasaanmu hari ini.</p>
      </section>

      {/* Selector */}
      <section className="bg-white p-8 rounded-[40px] border border-natural-border shadow-sm">
        <h3 className="text-lg font-bold mb-8 flex items-center gap-2 text-natural-brand">
          <span className="w-2 h-6 bg-natural-accent rounded-full"></span>
          Pilih Mood-mu
        </h3>
        
        <div className="grid grid-cols-3 gap-6 mb-8">
          {MOODS.map((m) => (
            <button
              key={m.type}
              onClick={() => setSelectedMood(m.type)}
              className={`flex flex-col items-center gap-3 p-4 rounded-3xl transition-all ${
                selectedMood === m.type 
                  ? `${m.bg} ring-2 ring-natural-accent/50 scale-105 shadow-sm` 
                  : 'hover:bg-natural-bg opacity-70 hover:opacity-100'
              }`}
            >
              <div className={`w-12 h-12 ${m.bg} rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110`}>
                <m.icon className={`w-8 h-8 ${m.color}`} />
              </div>
              <span className={`text-[10px] font-bold uppercase tracking-wider ${selectedMood === m.type ? 'text-natural-brand' : 'text-natural-tertiary'}`}>
                {m.label}
              </span>
            </button>
          ))}
        </div>

        <AnimatePresence>
          {selectedMood && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-5"
            >
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Ada yang ingin diceritakan singkat? (opsional)"
                className="w-full bg-natural-bg border border-natural-border rounded-3xl p-5 text-sm focus:outline-none focus:ring-2 focus:ring-natural-accent/30 transition-all min-h-[100px] placeholder:text-natural-tertiary/30"
              />
              <button
                onClick={handleSave}
                className="w-full bg-natural-brand text-white font-bold py-4 rounded-3xl shadow-lg shadow-natural-brand/10 active:scale-95 transition-all"
              >
                Simpan Mood
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* History */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg flex items-center gap-2">
             <span className="w-2 h-6 bg-natural-accent rounded-full"></span>
            Riwayat Terakhir
          </h3>
          <button className="text-[10px] text-natural-brand font-bold uppercase tracking-widest flex items-center gap-1">
            Statistik <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {entries.length === 0 ? (
          <div className="bg-white/40 p-12 rounded-[40px] border border-dashed border-natural-border text-center">
            <TrendingUp className="w-12 h-12 text-natural-border mx-auto mb-4" />
            <p className="text-[10px] text-natural-tertiary uppercase tracking-widest font-bold">Ayo mulai catat mood pertamamu</p>
          </div>
        ) : (
          <div className="space-y-4">
            {entries.map((entry) => {
              const config = getMoodConfig(entry.mood);
              return (
                <div key={entry.id} className="bg-white p-5 rounded-[32px] border border-natural-border flex items-center justify-between gap-5 transition-transform hover:scale-[1.01]">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${config.bg}`}>
                    <config.icon className={`w-8 h-8 ${config.color}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-natural-tertiary">{config.label}</p>
                    <p className="text-[10px] text-natural-tertiary/40 font-bold uppercase tracking-widest mt-0.5">
                      {new Date(entry.date).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short' })}
                    </p>
                    {entry.note && (
                      <p className="text-xs text-natural-tertiary/70 mt-2 line-clamp-2 italic leading-relaxed">
                        "{entry.note}"
                      </p>
                    )}
                  </div>
                  <div className="text-[10px] font-bold text-natural-accent bg-natural-light/30 px-3 py-1 rounded-full uppercase">
                    {new Date(entry.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
