import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { Send, User, Bot, Sparkles, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage } from '../types';

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial greeting
    if (messages.length === 0) {
      setMessages([
        {
          role: 'assistant',
          content: 'Halo Fakhri, sepertinya kamu sedang mencari teman untuk bercerita. Ada hal yang ingin kamu sampaikan hari ini?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input })
      });

      const data = await response.json();

      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Maaf, sepertinya ada gangguan koneksi. Bisa coba ceritakan lagi nanti?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[70vh] bg-natural-light rounded-[40px] border border-natural-accent overflow-hidden shadow-sm">
      {/* Chat header */}
      <div className="px-6 py-4 border-b border-natural-accent/30 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
          <Bot className="w-6 h-6 text-natural-brand" />
        </div>
        <div>
          <h3 className="font-bold text-natural-brand">Teman Cerita</h3>
          <p className="text-[10px] text-natural-brand/60 font-bold uppercase tracking-wider flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-natural-accent animate-pulse" />
            Empati & Mendengarkan
          </p>
        </div>
      </div>

      {/* Messages area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 bg-white/20"
      >
        {messages.map((msg, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[85%] rounded-[24px] px-5 py-3 text-sm shadow-sm ${
              msg.role === 'user' 
                ? 'bg-natural-accent text-white rounded-tr-none' 
                : 'bg-white text-natural-brand rounded-tl-none border border-white/50'
            }`}>
              <div className="prose prose-sm prose-gray max-w-none">
                <ReactMarkdown>{msg.content}</ReactMarkdown>
              </div>
              <p className={`text-[10px] mt-2 font-medium ${msg.role === 'user' ? 'text-white/70' : 'text-natural-tertiary/60'}`}>
                {msg.timestamp}
              </p>
            </div>
          </motion.div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white/80 px-5 py-3 rounded-[24px] rounded-tl-none border border-white/50 flex items-center gap-3">
              <Loader2 className="w-4 h-4 text-natural-accent animate-spin" />
              <span className="text-xs text-natural-tertiary font-bold tracking-tight">Mengetik...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input area */}
      <div className="p-6 border-t border-natural-accent/20 bg-white/40 backdrop-blur-sm">
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Tulis pesanmu..."
            className="w-full bg-white border-none rounded-2xl py-4 px-6 pr-14 text-sm focus:ring-2 focus:ring-natural-accent outline-none shadow-sm placeholder:text-natural-tertiary/40"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className={`absolute right-3 p-2.5 rounded-xl transition-all ${
              input.trim() && !loading ? 'bg-natural-accent text-white shadow-md' : 'bg-natural-muted text-natural-tertiary opacity-40'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
