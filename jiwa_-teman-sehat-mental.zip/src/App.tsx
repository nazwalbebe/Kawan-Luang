import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  MessageCircle, 
  BookOpen, 
  Calendar, 
  Settings as SettingsIcon,
  Home as HomeIcon,
  Sparkles,
  Coffee,
  Brain
} from 'lucide-react';
import Home from './components/Home';
import Chat from './components/Chat';
import MoodTracker from './components/MoodTracker';
import Journal from './components/Journal';
import SelfCare from './components/SelfCare';

type Tab = 'home' | 'chat' | 'mood' | 'journal' | 'self-care';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home');

  return (
    <div className="min-h-screen bg-natural-bg text-natural-text flex flex-col font-sans">
      {/* Header */}
      <header className="p-5 flex items-center justify-between border-b border-natural-border bg-white/80 backdrop-blur-sm sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-natural-light flex items-center justify-center">
            <Heart className="w-6 h-6 text-natural-brand" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-natural-brand">Jiwa.</h1>
        </div>
        <button className="p-2 rounded-xl bg-natural-muted text-natural-tertiary hover:bg-natural-border transition-colors">
          <SettingsIcon className="w-5 h-5" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-28">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="p-6 md:max-w-2xl md:mx-auto"
          >
            {activeTab === 'home' && <Home onNavigate={(tab) => setActiveTab(tab as Tab)} />}
            {activeTab === 'chat' && <Chat />}
            {activeTab === 'mood' && <MoodTracker />}
            {activeTab === 'journal' && <Journal />}
            {activeTab === 'self-care' && <SelfCare />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-6 left-6 right-6 bg-white/90 backdrop-blur-md border border-natural-border px-6 py-4 flex justify-between items-center z-40 rounded-[32px] shadow-sm max-w-xl mx-auto">
        <NavButton 
          active={activeTab === 'home'} 
          onClick={() => setActiveTab('home')} 
          icon={<HomeIcon className="w-6 h-6" />} 
          label="Beranda" 
        />
        <NavButton 
          active={activeTab === 'mood'} 
          onClick={() => setActiveTab('mood')} 
          icon={<Brain className="w-6 h-6" />} 
          label="Mood" 
        />
        <NavButton 
          active={activeTab === 'chat'} 
          onClick={() => setActiveTab('chat')} 
          icon={<MessageCircle className="w-6 h-6" />} 
          label="Jiwa" 
        />
        <NavButton 
          active={activeTab === 'journal'} 
          onClick={() => setActiveTab('journal')} 
          icon={<BookOpen className="w-6 h-6" />} 
          label="Jurnal" 
        />
        <NavButton 
          active={activeTab === 'self-care'} 
          onClick={() => setActiveTab('self-care')} 
          icon={<Coffee className="w-6 h-6" />} 
          label="Tips" 
        />
      </nav>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-all ${active ? 'text-natural-brand' : 'text-natural-tertiary opacity-50 hover:opacity-100'}`}
    >
      <div className={`p-1.5 rounded-xl transition-colors ${active ? 'bg-natural-light' : 'bg-transparent'}`}>
        {icon}
      </div>
      <span className="text-[10px] font-bold uppercase tracking-widest">{label}</span>
    </button>
  );
}
